## 2.1.0

* Deprecated `SharedPreferencesWindows.instance` in favor of `SharedPreferencesStorePlatform.instance`.

## 2.0.4

* Removes dependency on `meta`.

## 2.0.3

* Removed obsolete `pluginClass: none` from pubpsec.
* Fixes newly enabled analyzer options.

## 2.0.2

* Updated installation instructions in README.

## 2.0.1

* Add `implements` to pubspec.yaml.
* Add `registerWith` to the Dart main class.

## 2.0.0

* Migrate to null-safety.

## 0.0.2+3

* Remove 'ffi' dependency.

## 0.0.2+2

* Relax 'ffi' version constraint.

## 0.0.2+1

* Update Flutter SDK constraint.

## 0.0.2

* Update integration test examples to use `testWidgets` instead of `test`.

## 0.0.1+3

* Remove unused `test` dependency.

## 0.0.1+2

* Check in windows/ directory for example/

## 0.0.1+1

* Add iOS stub for compatibility with 1.17 and earlier.

## 0.0.1

* Initial release to support shared_preferences on Windows.
